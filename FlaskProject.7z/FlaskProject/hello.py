from flask import Flask, render_template, url_for

app = Flask(__name__)

posts = [
    {'author': 'Parin',
     'titile': 'Blog one!'}
]


@app.route("/")
def home_page():
    return render_template('home.html')


@app.route("/normal")
def normal_page():
    return render_template('normal.html', title='Normal')

@app.route("/beta")
def beta_page():
    return render_template('beta.html', title='Beta')
